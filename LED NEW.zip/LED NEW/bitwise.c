#include<reg51.h>
sbit inbit=P1^0;
bit membit;
sbit outbit=P2^7; 
void main(void)
{
while(1)
{
membit=inbit;
outbit=~membit;
}
}