#include<reg51.h> 
sbit Out = P2^0;
void cct_init(void);
void InitTimer1(void);
int main(void)
{
cct_init();
InitTimer1();
while(1)
{
}
}
void cct_init(void)
{
P0 = 0x00;
P1 = 0x00; 
P2 = 0x00;
P3 = 0x00;
}
void InitTimer1(void)
{
TMOD &= 0x0F;
TMOD |= 0x20;
TH1= 0x05; 
TL1 = 0x05;
ET1 = 1;
EA = 1;
TR1 = 1;
}
void Timer1_ISR (void) interrupt 3
{
Out = ~Out;
TF1 = 0;
}