#include<reg51.h>
sbit PWM_Pin = P2^0;
void cct_init(void);
void InitTimer0(void);
void InitPWM(void);
unsigned char PWM = 0;
unsigned int temp = 0;
#define PWM_Freq_Num 1
int main(void)
{
cct_init();
InitPWM();
PWM = 85;
while(1)
{}
}
void cct_init(void)
{
P0 = 0x00;
P1 = 0x00;
P2 = 0x00;
P3 = 0x00;
}
void InitTimer0(void)
{
TMOD &=0xF0;
TMOD |= 0x01;
TH0 = 0x00;
TL0 = 0x00;
ET0 = 1;
EA = 1;
TR0 = 1;
}
void InitPWM(void)
{
PWM = 0;
InitTimer0();
}
void Timer0_ISR (void) interrupt 1
{
TR0 = 0;
if(PWM_Pin)
{
PWM_Pin = 0;
temp = (255-PWM)*PWM_Freq_Num; 
TH0 = 0xFF - (temp>>8)&0xFF;
TL0 = 0xFF - temp&0xFF;
}
else
{
PWM_Pin = 1;
temp = PWM*PWM_Freq_Num;
TH0 = 0xFF - (temp>>8)&0xFF;
TL0 = 0xFF - temp&0xFF;
}
TF0 = 0;
TR0 = 1;
}